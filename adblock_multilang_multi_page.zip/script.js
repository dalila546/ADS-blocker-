
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

function shareSite() {
    if (navigator.share) {
        navigator.share({
            title: 'موقع حجب الإعلانات',
            text: 'جرب هذا الموقع الرائع لحجب الإعلانات!',
            url: window.location.href
        });
    } else {
        alert("ميزة المشاركة غير مدعومة في هذا المتصفح.");
    }
}

function changeLanguage(lang) {
    alert("الموقع متعدد اللغات قيد التطوير. اللغة المختارة: " + lang);
}
